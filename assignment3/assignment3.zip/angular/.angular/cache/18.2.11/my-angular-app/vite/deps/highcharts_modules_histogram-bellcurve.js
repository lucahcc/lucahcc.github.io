import {
  __commonJS
} from "./chunk-3OV72XIM.js";

// node_modules/highcharts/modules/histogram-bellcurve.js
var require_histogram_bellcurve = __commonJS({
  "node_modules/highcharts/modules/histogram-bellcurve.js"(exports, module) {
    !/**
    * Highcharts JS v11.4.8 (2024-08-29)
    *
    * (c) 2010-2024 Highsoft AS
    * Author: Sebastian Domas
    *
    * License: www.highcharts.com/license
    */
    function(e) {
      "object" == typeof module && module.exports ? (e.default = e, module.exports = e) : "function" == typeof define && define.amd ? define("highcharts/modules/histogram-bellcurve", ["highcharts"], function(t) {
        return e(t), e.Highcharts = t, e;
      }) : e("undefined" != typeof Highcharts ? Highcharts : void 0);
    }(function(e) {
      "use strict";
      var t = e ? e._modules : {};
      function s(t2, s2, i, r) {
        t2.hasOwnProperty(s2) || (t2[s2] = r.apply(null, i), "function" == typeof CustomEvent && e.win.dispatchEvent(new CustomEvent("HighchartsModuleLoaded", {
          detail: {
            path: s2,
            module: t2[s2]
          }
        })));
      }
      s(t, "Series/DerivedComposition.js", [t["Core/Globals.js"], t["Core/Series/Series.js"], t["Core/Utilities.js"]], function(e2, t2, s2) {
        var i;
        let {
          noop: r
        } = e2, {
          addEvent: a,
          defined: n
        } = s2;
        return function(e3) {
          function s3() {
            t2.prototype.init.apply(this, arguments), this.initialised = false, this.baseSeries = null, this.eventRemovers = [], this.addEvents();
          }
          function i2() {
            let e4 = this.chart, t3 = this.options.baseSeries, s4 = n(t3) && (e4.series[t3] || e4.get(t3));
            this.baseSeries = s4 || null;
          }
          function o() {
            this.eventRemovers.push(a(this.chart, "afterLinkSeries", () => {
              this.setBaseSeries(), this.baseSeries && !this.initialised && (this.setDerivedData(), this.addBaseSeriesEvents(), this.initialised = true);
            }));
          }
          function l() {
            this.eventRemovers.push(a(this.baseSeries, "updatedData", () => {
              this.setDerivedData();
            }), a(this.baseSeries, "destroy", () => {
              this.baseSeries = null, this.initialised = false;
            }));
          }
          function h() {
            this.eventRemovers.forEach((e4) => {
              e4();
            }), t2.prototype.destroy.apply(this, arguments);
          }
          e3.hasDerivedData = true, e3.setDerivedData = r, e3.compose = function(e4) {
            let t3 = e4.prototype;
            return t3.addBaseSeriesEvents = l, t3.addEvents = o, t3.destroy = h, t3.init = s3, t3.setBaseSeries = i2, e4;
          }, e3.init = s3, e3.setBaseSeries = i2, e3.addEvents = o, e3.addBaseSeriesEvents = l, e3.destroy = h;
        }(i || (i = {})), i;
      }), s(t, "Series/Histogram/HistogramSeriesDefaults.js", [], function() {
        return {
          binsNumber: "square-root",
          binWidth: void 0,
          pointPadding: 0,
          groupPadding: 0,
          grouping: false,
          pointPlacement: "between",
          tooltip: {
            headerFormat: "",
            pointFormat: '<span style="font-size: 0.8em">{point.x} - {point.x2}</span><br/><span style="color:{point.color}">●</span> {series.name} <b>{point.y}</b><br/>'
          }
        };
      }), s(t, "Series/Histogram/HistogramSeries.js", [t["Series/DerivedComposition.js"], t["Series/Histogram/HistogramSeriesDefaults.js"], t["Core/Series/SeriesRegistry.js"], t["Core/Utilities.js"]], function(e2, t2, s2, i) {
        let {
          column: r
        } = s2.seriesTypes, {
          arrayMax: a,
          arrayMin: n,
          correctFloat: o,
          extend: l,
          isNumber: h,
          merge: u
        } = i, d = {
          "square-root": function(e3) {
            return Math.ceil(Math.sqrt(e3.options.data.length));
          },
          sturges: function(e3) {
            return Math.ceil(Math.log(e3.options.data.length) * Math.LOG2E);
          },
          rice: function(e3) {
            return Math.ceil(2 * Math.pow(e3.options.data.length, 1 / 3));
          }
        };
        class p extends r {
          binsNumber() {
            let e3 = this.options.binsNumber, t3 = d[e3] || "function" == typeof e3 && e3;
            return Math.ceil(t3 && t3(this.baseSeries) || (h(e3) ? e3 : d["square-root"](this.baseSeries)));
          }
          derivedData(e3, t3, s3) {
            var i2;
            let r2;
            let l2 = o(a(e3)), u2 = o(n(e3)), d2 = [], p2 = {}, c = [];
            for (s3 = this.binWidth = o(h(s3) ? s3 || 1 : (l2 - u2) / t3), this.options.pointRange = Math.max(s3, 0), r2 = u2; r2 < l2 && (this.userOptions.binWidth || o(l2 - r2) >= s3 || 0 >= o(o(u2 + d2.length * s3) - r2)); r2 = o(r2 + s3)) d2.push(r2), p2[r2] = 0;
            0 !== p2[u2] && (d2.push(u2), p2[u2] = 0);
            let v = (i2 = d2.map((e4) => parseFloat(e4)), function(e4) {
              let t4 = 1;
              for (; i2[t4] <= e4; ) t4++;
              return i2[--t4];
            });
            for (let t4 of e3) p2[o(v(t4))]++;
            for (let e4 of Object.keys(p2)) c.push({
              x: Number(e4),
              y: p2[e4],
              x2: o(Number(e4) + s3)
            });
            return c.sort((e4, t4) => e4.x - t4.x), c[c.length - 1].x2 = l2, c;
          }
          setDerivedData() {
            let e3 = this.baseSeries.yData;
            if (!e3.length) {
              this.setData([]);
              return;
            }
            let t3 = this.derivedData(e3, this.binsNumber(), this.options.binWidth);
            this.setData(t3, false);
          }
        }
        return p.defaultOptions = u(r.defaultOptions, t2), l(p.prototype, {
          hasDerivedData: e2.hasDerivedData
        }), e2.compose(p), s2.registerSeriesType("histogram", p), p;
      }), s(t, "Series/Bellcurve/BellcurveSeriesDefaults.js", [], function() {
        return {
          intervals: 3,
          pointsInInterval: 3,
          marker: {
            enabled: false
          }
        };
      }), s(t, "Series/Bellcurve/BellcurveSeries.js", [t["Series/Bellcurve/BellcurveSeriesDefaults.js"], t["Series/DerivedComposition.js"], t["Core/Series/SeriesRegistry.js"], t["Core/Utilities.js"]], function(e2, t2, s2, i) {
        let {
          areaspline: r
        } = s2.seriesTypes, {
          correctFloat: a,
          isNumber: n,
          merge: o
        } = i;
        class l extends r {
          static mean(e3) {
            let t3 = e3.length, s3 = e3.reduce(function(e4, t4) {
              return e4 + t4;
            }, 0);
            return t3 > 0 && s3 / t3;
          }
          static standardDeviation(e3, t3) {
            let s3 = e3.length;
            t3 = n(t3) ? t3 : l.mean(e3);
            let i2 = e3.reduce((e4, s4) => {
              let i3 = s4 - t3;
              return e4 + i3 * i3;
            }, 0);
            return s3 > 1 && Math.sqrt(i2 / (s3 - 1));
          }
          static normalDensity(e3, t3, s3) {
            let i2 = e3 - t3;
            return Math.exp(-(i2 * i2) / (2 * s3 * s3)) / (s3 * Math.sqrt(2 * Math.PI));
          }
          derivedData(e3, t3) {
            let s3 = this.options, i2 = s3.intervals, r2 = s3.pointsInInterval, a2 = i2 * r2 * 2 + 1, n2 = t3 / r2, o2 = [], h = e3 - i2 * t3;
            for (let s4 = 0; s4 < a2; s4++) o2.push([h, l.normalDensity(h, e3, t3)]), h += n2;
            return o2;
          }
          setDerivedData() {
            this.baseSeries?.yData?.length && (this.setMean(), this.setStandardDeviation(), this.setData(this.derivedData(this.mean || 0, this.standardDeviation || 0), false, void 0, false));
          }
          setMean() {
            this.mean = a(l.mean(this.baseSeries.yData));
          }
          setStandardDeviation() {
            this.standardDeviation = a(l.standardDeviation(this.baseSeries.yData, this.mean));
          }
        }
        return l.defaultOptions = o(r.defaultOptions, e2), t2.compose(l), s2.registerSeriesType("bellcurve", l), l;
      }), s(t, "masters/modules/histogram-bellcurve.src.js", [t["Core/Globals.js"]], function(e2) {
        return e2;
      });
    });
  }
});
export default require_histogram_bellcurve();
//# sourceMappingURL=highcharts_modules_histogram-bellcurve.js.map
